using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Media;
using System.Windows.Forms;

namespace PanelCreate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Bomba şəkli (bomba.png faylı exe ilə eyni qovluqdadır)
            string sekil = Path.Combine(Application.StartupPath, "bomba.png");
            if (File.Exists(sekil))
                pictureBox1.Image = Image.FromFile(sekil);

            baslangicYeri = pictureBox1.Location;   // bombanın ilk yeri
        }

        Random r = new Random();
        Random g = new Random();
        Random b = new Random();

        Random xL = new Random();
        Random yL = new Random();

        int count = 0;                              // xal (yaradılan panel sayı)
        bool oyunBitdi = false;                     // oyunun bitib-bitmədiyini yoxlayır
        Point baslangicYeri;                        // bombanın ilk mövqeyi
        List<Panel> paneller = new List<Panel>();   // yaradılan panellərin siyahısı

        // Oyun sahəsinin sərhədləri (alt boz panelə qədər)
        int MaxX { get { return this.ClientSize.Width - 60; } }
        int MaxY { get { return panel1.Top - 60; } }

        // ===== Çıxış =====
        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        // ===== Panel yarat =====
        private void button1_Click(object sender, EventArgs e)
        {
            if (oyunBitdi) return;

            count++;
            Panel p = new Panel();
            p.Size = new Size(60, 60);
            p.BackColor = Color.FromArgb(r.Next(0, 256), g.Next(0, 256), b.Next(0, 256));
            p.Location = new Point(xL.Next(0, MaxX), yL.Next(0, MaxY));
            this.Controls.Add(p);
            paneller.Add(p);
            label2.Text = count.ToString();

            // Yeni panel bombaya toxunursa oyun bitir
            if (p.Bounds.IntersectsWith(pictureBox1.Bounds))
            {
                OyunuBitir();
            }
        }

        // ===== Bombanın yerini dəyiş =====
        private void button2_Click(object sender, EventArgs e)
        {
            if (oyunBitdi) return;

            pictureBox1.Location = new Point(xL.Next(0, MaxX), yL.Next(0, MaxY));
            pictureBox1.BringToFront();

            // Bomba hər hansı panelə toxunursa oyun bitir
            foreach (Panel p in paneller)
            {
                if (p.Bounds.IntersectsWith(pictureBox1.Bounds))
                {
                    OyunuBitir();
                    break;
                }
            }
        }

        // ===== Oyunun sonu =====
        private void OyunuBitir()
        {
            oyunBitdi = true;
            BombaSesiCal();

            DialogResult cavab = MessageBox.Show(
                "Panel bomba ilə toqquşdu! Oyun bitdi.\nSizin xalınız: " + count +
                "\n\nYeni oyun başlasın?",
                "Oyun bitdi",
                MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question);

            if (cavab == DialogResult.OK)
            {
                YeniOyun();
            }
            else
            {
                // Cancel seçilərsə düymələr bloklanır, oyun dayanır
                button1.Enabled = false;
                button2.Enabled = false;
            }
        }

        // ===== Bomba səsi =====
        private void BombaSesiCal()
        {
            try
            {
                string yol = Path.Combine(Application.StartupPath, "bomba.wav");
                if (File.Exists(yol))
                {
                    new SoundPlayer(yol).Play();
                }
                else
                {
                    SystemSounds.Hand.Play();   // fayl yoxdursa standart səs
                }
            }
            catch
            {
                SystemSounds.Hand.Play();
            }
        }

        // ===== Oyunu sıfırla və yenidən başlat =====
        private void YeniOyun()
        {
            foreach (Panel p in paneller)
            {
                this.Controls.Remove(p);
                p.Dispose();
            }
            paneller.Clear();

            count = 0;
            label2.Text = "0";
            pictureBox1.Location = baslangicYeri;

            button1.Enabled = true;
            button2.Enabled = true;
            oyunBitdi = false;
        }
    }
}
